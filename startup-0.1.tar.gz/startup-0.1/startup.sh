#!/bin/bash

for i in $(cat yum_installed); do
  yum -y install $i
done
